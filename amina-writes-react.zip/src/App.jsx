import React from 'react'
import { motion } from 'framer-motion'

export default function App() {
  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 text-gray-800 font-[system-ui]">
      <header className="bg-teal-700 text-white py-4 shadow">
        <div className="container mx-auto flex justify-between items-center px-4">
          <motion.h1 initial={{opacity:0, y:-20}} animate={{opacity:1, y:0}} className="text-2xl font-bold">
            Amina Writes
          </motion.h1>
          <nav className="space-x-4 rtl:space-x-reverse">
            <a href="#about" className="hover:underline">عنّي</a>
            <a href="#services" className="hover:underline">خدمات</a>
            <a href="#portfolio" className="hover:underline">أعمالي</a>
            <a href="#contact" className="bg-white text-teal-700 px-3 py-1 rounded-md">تواصل</a>
          </nav>
        </div>
      </header>

      <section className="container mx-auto text-center py-16 px-4">
        <motion.h2 initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} className="text-3xl font-semibold">
          مرحباً، أنا أمينة — كاتبة مقالات وقصص قصيرة ✨
        </motion.h2>
        <p className="mt-4 max-w-2xl mx-auto text-gray-600">
          أكتب قصصاً وأعمالاً أدبية ومحتوى تسويقياً بأسلوب راقٍ يلامس القارئ. هدفي تحويل الأفكار إلى كلمات تترك أثراً.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button className="bg-teal-700 text-white px-4 py-2 rounded-lg hover:bg-teal-800">اطلب خدمة</button>
          <button onClick={()=>document.getElementById('contact').scrollIntoView({behavior:'smooth'})} className="border border-teal-700 text-teal-700 px-4 py-2 rounded-lg hover:bg-teal-50">تواصل معي</button>
        </div>
      </section>

      <section id="services" className="container mx-auto py-12 px-4">
        <h3 className="text-2xl font-semibold mb-6 text-center">الخدمات</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <motion.div whileHover={{scale:1.03}} className="bg-white shadow p-6 rounded-xl">
            <h4 className="font-bold mb-2">كتابة قصص قصيرة</h4>
            <p>قصص أدبية بأسلوب جذّاب وتسليم بصيغ متعددة تناسب المنصات.</p>
          </motion.div>
          <motion.div whileHover={{scale:1.03}} className="bg-white shadow p-6 rounded-xl">
            <h4 className="font-bold mb-2">كتابة مقالات</h4>
            <p>مقالات ثقافية وتسويقية احترافية بأسلوب مشوّق وواضح.</p>
          </motion.div>
          <motion.div whileHover={{scale:1.03}} className="bg-white shadow p-6 rounded-xl">
            <h4 className="font-bold mb-2">تدقيق لغوي وتنقيح</h4>
            <p>تحسين النصوص لغوياً وأسلوبياً لتبدو أكثر سلاسة واحترافاً.</p>
          </motion.div>
        </div>
      </section>

      <section id="portfolio" className="container mx-auto py-12 px-4">
        <h3 className="text-2xl font-semibold mb-6 text-center">نماذج من أعمالي</h3>
        <div className="grid md:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <motion.div key={i} whileHover={{scale:1.02}} className="bg-white rounded-xl shadow overflow-hidden">
              <img src={`https://picsum.photos/seed/${i}/800/600`} alt={`عمل ${i}`} className="w-full h-48 object-cover"/>
              <div className="p-4">
                <p className="text-gray-700">نموذج رقم {i} من أعمالي في الكتابة أو التصميم الأدبي.</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="contact" className="bg-white py-12 px-4 shadow-inner">
        <div className="container mx-auto max-w-lg">
          <h3 className="text-2xl font-semibold mb-4 text-center">تواصل معي</h3>
          <form className="space-y-4">
            <div>
              <label className="block mb-1">الاسم</label>
              <input type="text" className="w-full border border-gray-300 rounded-lg p-2" placeholder="اسمك" required/>
            </div>
            <div>
              <label className="block mb-1">البريد الإلكتروني</label>
              <input type="email" className="w-full border border-gray-300 rounded-lg p-2" placeholder="example@mail.com" required/>
            </div>
            <div>
              <label className="block mb-1">الرسالة</label>
              <textarea rows="4" className="w-full border border-gray-300 rounded-lg p-2" placeholder="اكتب رسالتك هنا"></textarea>
            </div>
            <button type="submit" className="bg-teal-700 text-white px-4 py-2 rounded-lg hover:bg-teal-800 w-full">إرسال</button>
          </form>
        </div>
      </section>

      <footer className="text-center text-gray-500 py-6 text-sm">
        © {new Date().getFullYear()} Amina Writes — جميع الحقوق محفوظة.
      </footer>
    </div>
  )
}